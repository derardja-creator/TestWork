export class Event {
    id? :number;
    name: string;
    address: string;
    date: string;
}