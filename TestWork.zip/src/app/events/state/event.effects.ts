import { Injectable } from "@angular/core";

import { Actions, Effect, ofType } from "@ngrx/effects";
import { Action } from "@ngrx/store";

import { Observable, of } from "rxjs";
import { map, mergeMap, catchError } from "rxjs/operators";

import { EventService } from "../event.service";
import * as eventActions from "../state/event.actions";
import { Event } from "../event.model";

@Injectable()
export class EventEffect {
  constructor(
    private actions$: Actions,
    private eventService: EventService
  ) {}

  @Effect()
  loadCustomers$: Observable<Action> = this.actions$.pipe(
    ofType<eventActions.LoadEvents>(
      eventActions.EventActionTypes.LOAD_EVENTS
    ),
    mergeMap((action: eventActions.LoadEvents) =>
      this.eventService.getEvents().pipe(
        map(
          (events: Event[]) =>
            new eventActions.LoadEventsSuccess(events)
        ),
        catchError(err => of(new eventActions.LoadEventsFail(err)))
      )
    )
  );

  @Effect()
  loadEvents$: Observable<Action> = this.actions$.pipe(
    ofType<eventActions.LoadEvent>(
      eventActions.EventActionTypes.LOAD_EVENT
    ),
    mergeMap((action: eventActions.LoadEvent) =>
      this.eventService.getEventById(action.payload).pipe(
        map(
          (event: Event) =>
            new eventActions.LoadEventSuccess(event)
        ),
        catchError(err => of(new eventActions.LoadEventFail(err)))
      )
    )
  );

  @Effect()
  createEvent$: Observable<Action> = this.actions$.pipe(
    ofType<eventActions.CreateEvent>(
      eventActions.EventActionTypes.CREATE_EVENT
    ),
    map((action: eventActions.CreateEvent) => action.payload),
    mergeMap((event: Event) =>
      this.eventService.createEvent(event).pipe(
        map(
          (newEvent: Event) =>
            new eventActions.CreateEventSuccess(newEvent)
        ),
        catchError(err => of(new eventActions.CreateEventFail(err)))
      )
    )
  );

  @Effect()
  updateEvent$: Observable<Action> = this.actions$.pipe(
    ofType<eventActions.UpdateEvent>(
      eventActions.EventActionTypes.UPDATE_EVENT
    ),
    map((action: eventActions.UpdateEvent) => action.payload),
    mergeMap((event: Event) =>
      this.eventService.updateEvent(event).pipe(
        map(
          (updateEvent: Event) =>
            new eventActions.UpdateEventSuccess({
              id: updateEvent.id,
              changes: updateEvent
            })
        ),
        catchError(err => of(new eventActions.UpdateEventFail(err)))
      )
    )
  );

  @Effect()
  deleteEvent$: Observable<Action> = this.actions$.pipe(
    ofType<eventActions.DeleteEvent>(
      eventActions.EventActionTypes.DELETE_EVENT
    ),
    map((action: eventActions.DeleteEvent) => action.payload),
    mergeMap((id: number) =>
      this.eventService.deleteEvent(id).pipe(
        map(() => new eventActions.DeleteEventSuccess(id)),
        catchError(err => of(new eventActions.DeleteEventFail(err)))
      )
    )
  );
}
