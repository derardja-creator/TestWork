import { Action } from "@ngrx/store";

import { Update } from "@ngrx/entity";

import { Event } from "../event.model";

export enum EventActionTypes {
  LOAD_EVENTS = "[Event] Load Events",
  LOAD_EVENTS_SUCCESS = "[Event] Load Events Success",
  LOAD_EVENTS_FAIL = "[Event] Load Events Fail",
  LOAD_EVENT = "[Event] Load Event",
  LOAD_EVENT_SUCCESS = "[Event] Load Event Success",
  LOAD_EVENT_FAIL = "[Event] Load Event Fail",
  CREATE_EVENT = "[Event] Create Event",
  CREATE_EVENT_SUCCESS = "[Event] Create Event Success",
  CREATE_EVENT_FAIL = "[Event] Create Event Fail",
  UPDATE_EVENT = "[Event] Update Event",
  UPDATE_EVENT_SUCCESS = "[Event] Update Event Success",
  UPDATE_EVENT_FAIL = "[Event] Update Event Fail",
  DELETE_EVENT = "[Event] Delete Event",
  DELETE_EVENT_SUCCESS = "[Event] Delete Event Success",
  DELETE_EVENT_FAIL = "[Event] Delete Event Fail"
}

export class LoadEvents implements Action {
  readonly type = EventActionTypes.LOAD_EVENTS;
}

export class LoadEventsSuccess implements Action {
  readonly type = EventActionTypes.LOAD_EVENTS_SUCCESS;

  constructor(public payload: Event[]) {}
}

export class LoadEventsFail implements Action {
  readonly type = EventActionTypes.LOAD_EVENTS_FAIL;

  constructor(public payload: string) {}
}

export class LoadEvent implements Action {
  readonly type = EventActionTypes.LOAD_EVENT;

  constructor(public payload: number) {}
}

export class LoadEventSuccess implements Action {
  readonly type = EventActionTypes.LOAD_EVENT_SUCCESS;

  constructor(public payload: Event) {}
}

export class LoadEventFail implements Action {
  readonly type = EventActionTypes.LOAD_EVENT_FAIL;

  constructor(public payload: string) {}
}

export class CreateEvent implements Action {
  readonly type = EventActionTypes.CREATE_EVENT;

  constructor(public payload: Event) {}
}

export class CreateEventSuccess implements Action {
  readonly type = EventActionTypes.CREATE_EVENT_SUCCESS;

  constructor(public payload: Event) {}
}

export class CreateEventFail implements Action {
  readonly type = EventActionTypes.CREATE_EVENT_FAIL;

  constructor(public payload: string) {}
}

export class UpdateEvent implements Action {
  readonly type = EventActionTypes.UPDATE_EVENT;

  constructor(public payload: Event) {}
}

export class UpdateEventSuccess implements Action {
  readonly type = EventActionTypes.UPDATE_EVENT_SUCCESS;

  constructor(public payload: Update<Event>) {}
}

export class UpdateEventFail implements Action {
  readonly type = EventActionTypes.UPDATE_EVENT_FAIL;

  constructor(public payload: string) {}
}

export class DeleteEvent implements Action {
  readonly type = EventActionTypes.DELETE_EVENT;

  constructor(public payload: number) {}
}

export class DeleteEventSuccess implements Action {
  readonly type = EventActionTypes.DELETE_EVENT_SUCCESS;

  constructor(public payload: number) {}
}

export class DeleteEventFail implements Action {
  readonly type = EventActionTypes.DELETE_EVENT_FAIL;

  constructor(public payload: string) {}
}

export type Action =
  | LoadEvents
  | LoadEventsSuccess
  | LoadEventsFail
  | LoadEvent
  | LoadEventSuccess
  | LoadEventFail
  | CreateEvent
  | CreateEventSuccess
  | CreateEventFail
  | UpdateEvent
  | UpdateEventSuccess
  | UpdateEventFail
  | DeleteEvent
  | DeleteEventSuccess
  | DeleteEventFail;
