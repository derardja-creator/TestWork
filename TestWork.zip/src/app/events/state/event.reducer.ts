import * as eventActions from "./event.actions";
import { createFeatureSelector, createSelector } from "@ngrx/store";

import { EntityState, EntityAdapter, createEntityAdapter } from "@ngrx/entity";

import { Event } from "../event.model";
import * as fromRoot from "../../state/app-state";

export interface EventState extends EntityState<Event> {
  selectedEventId: number | null;
  loading: boolean;
  loaded: boolean;
  error: string;
}

export interface AppState extends fromRoot.AppState {
  events: EventState;
}

export const eventAdapter: EntityAdapter<Event> = createEntityAdapter<
  Event
>();

export const defaultEvent: EventState = {
  ids: [],
  entities: {},
  selectedEventId: null,
  loading: false,
  loaded: false,
  error: ""
};

export const initialState = eventAdapter.getInitialState(defaultEvent);

export function eventReducer(
  state = initialState,
  action: eventActions.Action
): EventState {
  switch (action.type) {
    case eventActions.EventActionTypes.LOAD_EVENTS_SUCCESS: {
      return eventAdapter.addAll(action.payload, {
        ...state,
        loading: false,
        loaded: true
      });
    }
    case eventActions.EventActionTypes.LOAD_EVENTS_FAIL: {
      return {
        ...state,
        entities: {},
        loading: false,
        loaded: false,
        error: action.payload
      };
    }

    case eventActions.EventActionTypes.LOAD_EVENT_SUCCESS: {
      return eventAdapter.addOne(action.payload, {
        ...state,
        selectedEventId: action.payload.id
      });
    }
    case eventActions.EventActionTypes.LOAD_EVENT_FAIL: {
      return {
        ...state,
        error: action.payload
      };
    }

    case eventActions.EventActionTypes.CREATE_EVENT_SUCCESS: {
      return eventAdapter.addOne(action.payload, state);
    }
    case eventActions.EventActionTypes.CREATE_EVENT_FAIL: {
      return {
        ...state,
        error: action.payload
      };
    }

    case eventActions.EventActionTypes.UPDATE_EVENT_SUCCESS: {
      return eventAdapter.updateOne(action.payload, state);
    }
    case eventActions.EventActionTypes.UPDATE_EVENT_FAIL: {
      return {
        ...state,
        error: action.payload
      };
    }

    case eventActions.EventActionTypes.DELETE_EVENT_SUCCESS: {
      return eventAdapter.removeOne(action.payload, state);
    }
    case eventActions.EventActionTypes.DELETE_EVENT_FAIL: {
      return {
        ...state,
        error: action.payload
      };
    }

    default: {
      return state;
    }
  }
}

const getEventFeatureState = createFeatureSelector<EventState>(
  "events"
);

export const getEvents = createSelector(
  getEventFeatureState,
  eventAdapter.getSelectors().selectAll
);

export const getEventsLoading = createSelector(
  getEventFeatureState,
  (state: EventState) => state.loading
);

export const getEventsLoaded = createSelector(
  getEventFeatureState,
  (state: EventState) => state.loaded
);

export const getError = createSelector(
  getEventFeatureState,
  (state: EventState) => state.error
);

export const getCurrenEventId = createSelector(
  getEventFeatureState,
  (state: EventState) => state.selectedEventId
);
export const getCurrentEvent = createSelector(
  getEventFeatureState,
  getCurrenEventId,
  state => state.entities[state.selectedEventId]
);
