import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';

import * as eventActions from "../state/event.actions";
import * as fromEvent from "../state/event.reducer";
import { Event } from "../event.model";

@Component({
  selector: 'app-event-add',
  templateUrl: './event-add.component.html',
  styleUrls: ['./event-add.component.css']
})
export class EventAddComponent implements OnInit {
  eventForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private store: Store<fromEvent.AppState>
  ) {}

  ngOnInit() {
    this.eventForm = this.fb.group({
      name: ["", Validators.required],
      address: ["", Validators.required],
      date: ["", Validators.required]
    });
  }

  createEvent() {
    const newEvent: Event = {
      name: this.eventForm.get("name").value,
      address: this.eventForm.get("address").value,
      date: this.eventForm.get("date").value
    };

    this.store.dispatch(new eventActions.CreateEvent(newEvent));

    this.eventForm.reset();
  }

}
