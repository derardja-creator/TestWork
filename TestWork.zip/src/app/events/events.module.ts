import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EventAddComponent } from './event-add/event-add.component';
import { EventEditComponent } from './event-edit/event-edit.component';
import { EventListComponent } from './event-list/event-list.component';

import { RouterModule, Routes } from "@angular/router";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";

import { EffectsModule, Actions } from "@ngrx/effects";
import { StoreModule } from "@ngrx/store";

import { eventReducer } from "./state/event.reducer";
import { EventEffect } from "./state/event.effects";
import { EventComponent } from './event/event.component';

const eventRoutes: Routes = [{ path: "", component: EventComponent }];


@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(eventRoutes),
    StoreModule.forFeature("events", eventReducer),
    EffectsModule.forFeature([EventEffect])
  ],
  declarations: [EventComponent, EventAddComponent, EventEditComponent, EventListComponent]
})
export class EventsModule { }
