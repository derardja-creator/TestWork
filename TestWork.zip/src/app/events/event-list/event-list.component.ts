import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { Store, select } from "@ngrx/store";

import * as eventActions from "../state/event.actions";
import * as fromEvent from "../state/event.reducer";
import { Event } from "../event.model";

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.css']
})
export class EventListComponent implements OnInit {

  events$: Observable<Event[]>;
  error$: Observable<String>;

  constructor(private store: Store<fromEvent.AppState>) {}

  ngOnInit() {
    this.store.dispatch(new eventActions.LoadEvents());
    this.events$ = this.store.pipe(select(fromEvent.getEvents));
    this.error$ = this.store.pipe(select(fromEvent.getError));
  }

  deleteEvent(event: Event) {
    if (confirm("Are You Sure You want to Delete the User?")) {
      this.store.dispatch(new eventActions.DeleteEvent(event.id));
    }
  }

  editCustomer(event: Event) {
    this.store.dispatch(new eventActions.LoadEvent(event.id));
  }

}
