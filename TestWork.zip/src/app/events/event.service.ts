import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

import { Observable } from "rxjs";

import { Event } from "./event.model";

@Injectable({
  providedIn: "root"
})
export class EventService {
  private eventsUrl = "http://localhost:3000/events";

  constructor(private http: HttpClient) {}

  getEvents(): Observable<Event[]> {
    return this.http.get<Event[]>(this.eventsUrl);
  }

  getEventById(payload: number): Observable<Event> {
    return this.http.get<Event>(`${this.eventsUrl}/${payload}`);
  }

  createEvent(payload: Event): Observable<Event> {
    return this.http.post<Event>(this.eventsUrl, payload);
  }

  updateEvent(event: Event): Observable<Event> {
    return this.http.patch<Event>(
      `${this.eventsUrl}/${event.id}`,
      event
    );
  }

  deleteEvent(payload: number) {
    return this.http.delete(`${this.eventsUrl}/${payload}`);
  }
}
