import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Store } from "@ngrx/store";

import { Observable } from "rxjs";

import * as eventActions from "../state/event.actions";
import * as fromEvent from "../state/event.reducer";
import { Event } from "../event.model";

@Component({
  selector: 'app-event-edit',
  templateUrl: './event-edit.component.html',
  styleUrls: ['./event-edit.component.css']
})
export class EventEditComponent implements OnInit {

  eventForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private store: Store<fromEvent.AppState>
  ) { }

  ngOnInit() {
    this.eventForm = this.fb.group({
      name: ["", Validators.required],
      address: ["", Validators.required],
      date: ["", Validators.required],
      id: null
    })

    const event$: Observable<Event> = this.store.select(
      fromEvent.getCurrentEvent
    )

    event$.subscribe(currentEvent => {
      if (currentEvent) {
        this.eventForm.patchValue({
          name: currentEvent.name,
          address: currentEvent.address,
          date: currentEvent.date,
          id: currentEvent.id
        });
      }
    })
  }

  updateEvent() {
    const updatedEvent: Event = {
      name: this.eventForm.get("name").value,
      address: this.eventForm.get("address").value,
      date: this.eventForm.get("date").value,
      id: this.eventForm.get("id").value
    };

    this.store.dispatch(new eventActions.UpdateEvent(updatedEvent))
  }

}
